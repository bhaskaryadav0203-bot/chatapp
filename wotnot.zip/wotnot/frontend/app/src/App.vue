<template>
  <div id="app">
    <router-view />
  </div>
</template>

<script>
export default {
  name: 'App',
};
</script>

<style>
.Toastify__toast-container {
  z-index: 99999 !important;
}
</style>