<template>
  <div class="content-section m-8 md:ml-72">
    
    <h2>Coming Soon...</h2>
    <p>Your content for scheduled broadcasts goes here.</p>
      
</div>
</template>
  
  <script>
  export default {
    name: 'ContActs2',
    data() {
     
    },
    methods: {

     
      
    }
  }
  </script>
  
  <style scoped>
  /* Add your styles here */
  </style>
  